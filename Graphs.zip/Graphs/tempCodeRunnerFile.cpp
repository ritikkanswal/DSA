g.addEdge(0,2);
//   g.addEdge(0,3);
//   g.addEdge(2,1);
//   g.addEdge(2,3);
//   g.addEdge(1,3);